import React from 'react';

function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-black to-gray-900 text-red-600">
      <h1 className="text-6xl font-bold drop-shadow-lg">👻 Haunted Farm 👻</h1>
      <p className="mt-4 text-lg">Dare to enter? Coming Halloween 2025</p>
      {/* Ticketing coming soon... */}
    </div>
  );
}

export default App;
